export enum Mode {
    EDIT = 1,
    CREATE = 2,
    DELETE = 3
}