import Guilds from "./index";

export default {
    path: "/guilds",
    component: <Guilds />,
    sidebar: true,
    topRight: []
} as BlacketRoute;
