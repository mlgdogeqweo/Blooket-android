export default function GuildDiscovery() {
    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                fontSize: 25,
                marginTop: 50,
                textAlign: "center"
            }}>
            This page is currently work in progress and will be available in the future.
        </div>
    );
}
