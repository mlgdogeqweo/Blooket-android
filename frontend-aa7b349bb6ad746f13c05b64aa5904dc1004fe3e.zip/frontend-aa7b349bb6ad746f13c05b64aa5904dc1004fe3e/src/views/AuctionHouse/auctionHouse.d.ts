import { AuctionsAuctionEntity } from "@blacket/types";

export interface AuctionModalProps {
    auctionId: number;
}

export interface ModalProps {
    auction: AuctionsAuctionEntity;
}
