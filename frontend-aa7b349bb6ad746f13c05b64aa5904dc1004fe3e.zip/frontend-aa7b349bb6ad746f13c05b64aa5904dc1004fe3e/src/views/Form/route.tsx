import Form from "./index";

export default {
    path: "/form",
    component: <Form />,
    header: {}
} as BlacketRoute;
