import styles from "../home.module.scss";

export default function Divider() {
    return <div className={styles.headerSide} />;
}
