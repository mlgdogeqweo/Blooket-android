import Section from "./Section";
import Title from "./Title";
import UpdatedAt from "./UpdatedAt";

export {
    Section,
    Title,
    UpdatedAt
};
