import Legal from "./index";

export default {
    path: "/legal",
    component: <Legal />,
    header: {}
} as BlacketRoute;
