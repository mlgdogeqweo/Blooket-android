import styles from "../contextMenu.module.scss";

export default function Divider() {
    return <div className={styles.divider} />;
}
