import NotificationAccessModal from "./NotificationAccessModal";

export {
    NotificationAccessModal
};
