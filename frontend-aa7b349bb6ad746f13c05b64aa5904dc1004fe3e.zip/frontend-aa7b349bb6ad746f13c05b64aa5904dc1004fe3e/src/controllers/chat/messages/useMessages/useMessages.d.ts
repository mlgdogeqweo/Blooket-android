import { Message } from "@blacket/types";

export interface MessagesResponse {
    data: Messsage[];
}
