import { DiscordLinkDto } from "@blacket/types";

export interface DiscordLinkResponse {
    data: DiscordLinkDto;
}
