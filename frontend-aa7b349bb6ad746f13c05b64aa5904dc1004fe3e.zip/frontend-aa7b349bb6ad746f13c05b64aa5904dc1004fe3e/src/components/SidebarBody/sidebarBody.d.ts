import { HTMLAttributes } from "react";

export interface SidebarBodyProps extends HTMLAttributes<HTMLDivElement> {
    pushOnMobile: boolean;
}