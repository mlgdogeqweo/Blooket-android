export interface HeaderProps {
    noLink?: boolean,
    right?: {
        link: string,
        text: string
    }
}
