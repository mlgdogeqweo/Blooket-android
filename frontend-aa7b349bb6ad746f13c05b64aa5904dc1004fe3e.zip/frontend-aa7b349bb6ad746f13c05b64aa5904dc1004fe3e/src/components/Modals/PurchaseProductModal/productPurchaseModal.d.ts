import { Product } from "@blacket/types";

export interface ProductPurchaseModalProps {
    product: Product;
}
