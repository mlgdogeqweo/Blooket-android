import { HTMLAttributes } from "react";

export interface ModalDropdownContainerProps extends HTMLAttributes<HTMLDivElement> { }
