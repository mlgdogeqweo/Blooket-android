import { ReactNode } from "react";

export interface ErrorModalProps {
    onClick?: () => void;
    children: ReactNode;
}
