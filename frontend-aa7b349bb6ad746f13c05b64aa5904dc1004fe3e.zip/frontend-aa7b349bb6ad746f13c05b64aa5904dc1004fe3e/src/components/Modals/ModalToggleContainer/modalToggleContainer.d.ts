import { HTMLAttributes } from "react";

export interface ModalToggleContainerProps extends HTMLAttributes<HTMLDivElement> { }
