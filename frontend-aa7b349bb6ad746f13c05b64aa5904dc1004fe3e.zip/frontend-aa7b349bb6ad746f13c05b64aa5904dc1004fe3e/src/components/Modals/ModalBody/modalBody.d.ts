import { HTMLAttributes } from "react";

export interface ModalBodyProps extends HTMLAttributes<HTMLDivElement> { }
