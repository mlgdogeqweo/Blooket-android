import { HTMLAttributes } from "react";

export interface LittleButtonProps extends HTMLAttributes<HTMLDivElement> {
    className?: string;
}
