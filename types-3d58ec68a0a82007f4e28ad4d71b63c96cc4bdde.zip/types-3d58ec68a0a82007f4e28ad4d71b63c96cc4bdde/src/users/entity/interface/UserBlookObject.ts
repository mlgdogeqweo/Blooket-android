export interface UserBlookObject {
    [blookId: number]: number;
}
