export enum InternalServerError {
    DEFAULT = "Something went wrong."
};
