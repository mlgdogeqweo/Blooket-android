export enum Unauthorized {
    DEFAULT = "Unauthorized.",
    AUTH_MISSING_OTP = "OTP is required."
};
