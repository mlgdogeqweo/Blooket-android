export * from "./newsPost.entity";
