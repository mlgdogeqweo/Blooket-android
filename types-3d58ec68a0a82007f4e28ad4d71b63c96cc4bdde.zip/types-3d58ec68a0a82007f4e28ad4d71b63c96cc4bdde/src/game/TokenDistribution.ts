export interface TokenDistribution {
	chance: number;
	amount: number;
}